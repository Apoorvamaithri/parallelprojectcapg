package com.cg.plp.exception;

public class BankAccountException extends Exception{
	public BankAccountException(String message){
		super(message);
	}
}
