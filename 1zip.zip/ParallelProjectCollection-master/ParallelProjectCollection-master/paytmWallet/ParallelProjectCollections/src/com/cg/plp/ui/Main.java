package com.cg.plp.ui;

import java.util.Scanner;

import com.cg.plp.dto.Customer;
import com.cg.plp.exception.BankAccountException;
import com.cg.plp.service.BankServiceImpl;

public class Main {
	public static void main(String args[]) throws BankAccountException{
		
		BankServiceImpl service = new BankServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		
		String name,contactNo;
		float age;
		double amount;
		int ch = 0;
		do{
			System.out.println("1.Add Customer\n2.Deposit amount\n3.Withdraw Amount\n4.Fund transfer\n5.Check balance\n6.Exit");
			System.out.println("Enter your choice : ");
			ch = sc.nextInt();
			Customer customer;

			switch(ch){
				case 1 :					
						do{
							do{
							System.out.println("Enter customer name : ");
							name = sc.next();
							if(service.validateName(name))
								break;
							}while(true);
							
							do{
							System.out.println("Enter contact no. : ");
							contactNo = sc.next();
							if(service.validateContactNo(contactNo))
								break;
							}while(true);
							
							do{
							System.out.println("Enter age : ");
							age = sc.nextFloat();
							if(service.validateAge(age))
								break;
							}while(true);
							
							do{
							System.out.println("Enter initial amount : ");
							amount = sc.nextDouble();
							if(service.validateAmount(amount))
								break;
							}while(true);
							
							if(service.validateAccount(contactNo))
								System.out.println("Account already exists!");
							else
								break;
							
						}while(true);
						
						customer = new Customer();
						customer.setName(name);
						customer.setContactNo(contactNo);
						customer.setAge(age);
						customer.setInitialBalance(amount);
						service.createAccount(customer);		
						System.out.println("Customer added!");
					break;
					
				case 2 :
						do{
							do{
								System.out.println("Enter your contact no. : ");
								contactNo = sc.next();
								if(service.validateContactNo(contactNo))
									break;
								}while(true);
							
							do{
								System.out.println("Enter amount you want to deposit: ");
								amount = sc.nextDouble();
								if(service.validateAmount(amount))
									break;
								}while(true);

							if(!service.validateAccount(contactNo))
								System.out.println("Account not found! Check contact number");
							else
								break;
						}while(true);
						
						service.deposit(contactNo, amount);		
					
					break;
					
				case 3 :
					do{
						do{
							System.out.println("Enter your contact no. : ");
							contactNo = sc.next();
							if(service.validateContactNo(contactNo))
								break;
							}while(true);
						
						do{
							System.out.println("Enter amount you want to withdraw: ");
							amount = sc.nextDouble();
							if(service.validateAmount(amount))
								break;
							}while(true);

						if(!service.validateAccount(contactNo))
							System.out.println("Account not found! Check mobile number");
						else
							break;
					}while(true);
					
					customer = new Customer();
					service.withdraw(contactNo, amount);
						
					break;
				
				case 4 :
						String contactNoReciever;
						do{
							do{
							System.out.println("Enter your mobile number : ");
							contactNo = sc.next();
							if(service.validateContactNo(contactNo)){
								if(service.validateAccount(contactNo))
									break;
								else
									System.out.println("Account doesnt exists!");
							}
							}while(true);
							
							do{
							System.out.println("Enter the amount you want to transfer : ");
							amount = sc.nextDouble();
							if(service.validateAmount(amount))
								break;
							}while(true);
							
							do{
							System.out.println("Enter receivers contact number : ");
							contactNoReciever = sc.next();
							if(service.validateContactNo(contactNoReciever)){
								if(service.validateAccount(contactNoReciever))
									break;
								else
									System.out.println("Account doesnt exists!");
							}
							}while(true);
							
							if(!contactNo.equals(contactNoReciever))
								break;
							else
								System.out.println("Sender and receiver mobile number cannot be same.");
							}while(true);							
						service.fundTransfer(contactNo, contactNoReciever, amount);
						break;
					
				case 5 :
						do{
							System.out.println("Enter the moible id to check balance");
							contactNo = sc.next();
							if(service.validateContactNo(contactNo)){
								if(service.validateAccount(contactNo))
									break;
								else
									System.out.println("Account doesnot exists!");
							}
						}while(true);
						
						System.out.println("Current Amount "+service.checkBalance(contactNo));
						
					break;
					
				case 6 :
						System.out.println("Application terminated");
					break;
				default : System.out.println("Invalid input!");
			}
			
		}while(ch != 6);
		sc.close();
		
	}
}
