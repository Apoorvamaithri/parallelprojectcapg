package com.cg.plp.dao;

import java.util.HashMap;
import java.util.Map;


import com.cg.plp.dto.Customer;
import com.cg.plp.exception.BankAccountException;

public class BankingDAOImpl implements BankingDAO{
	

	Map<String,Customer> custMap;
	
	public BankingDAOImpl(){
	custMap = new HashMap<>();
	custMap.put("9652008170", new Customer("9652008170", "sreya", 40, 5000));
	custMap.put("7674914630", new Customer("7674914630", "ritu", 45, 6000));
	custMap.put("9963079554", new Customer("9963079554", "mahesh", 23, 10000));
	}
	
	@Override
	public void createAccount(Customer customer) {
		custMap.put(customer.getContactNo(),customer);
		
	}

	@Override
	public void deposit(String contactNo, double amount) {
		Customer customer = custMap.get(contactNo);
		if(customer != null){
			double updateAmount = customer.getInitialBalance();
			updateAmount += amount;
			String name = customer.getName();
			String newcontactNo = customer.getContactNo();
			float age = customer.getAge();
			
			customer.setAge(age);
			customer.setInitialBalance(updateAmount);
			customer.setName(name);
			customer.setContactNo(newcontactNo);
			
			custMap.put(newcontactNo, customer);
			System.out.println("AMOUNT DEPOSITED!! CURRENT BALANCE: "+ customer.getInitialBalance());
		}
	}

	@Override
	public void withdraw(String contactNo, double withdrawAmount) {
		Customer customer = custMap.get(contactNo);
		if(customer != null){
			double amount = customer.getInitialBalance();	
			
			String name = customer.getName();
			String newcontactNo = customer.getContactNo();
			float age = customer.getAge();
			
			if(amount - withdrawAmount > 500){
				amount -= withdrawAmount;
				customer.setAge(age);
				customer.setInitialBalance(amount);
				customer.setName(name);
				customer.setContactNo(newcontactNo);
				
				custMap.put(newcontactNo, customer);
				System.out.println("AMOUNT WITHDRAWN! CURRENT BALANCE: "+ customer.getInitialBalance());
			}
			else{
				System.out.println("CANNOT WITHDRAW! MINIMUM BALANCE OF 500 SHOULD BE MAINTAINED");
			}
			}
		else{
			System.out.println("CONTACT NUMBER NOT FOUND");
		}
		
	}

	@Override
	public double checkBalance(String contactNo) {
		Customer custCheckBalance = custMap.get(contactNo);
		double amount = custCheckBalance.getInitialBalance();
		return amount;
		
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		String name, newcontactNo;
		float age;
		
		Customer custSender =  custMap.get(sender);
		Customer custReciever = custMap.get(reciever);
		
		double recieverAmount = custReciever.getInitialBalance();
		double senderAmount = custSender.getInitialBalance();
		if(senderAmount - amount > 500){
			recieverAmount += amount;
			senderAmount -= amount;
			name = custSender.getName();
			newcontactNo = custSender.getContactNo();
			age = custSender.getAge();
		
			
			custSender.setAge(age);
			custSender.setInitialBalance(senderAmount);
			custSender.setContactNo(newcontactNo);
			custSender.setName(name);
			
			custMap.put(newcontactNo, custSender);
			
			name = custReciever.getName();
			newcontactNo = custReciever.getContactNo();
			age = custReciever.getAge();
			
			
			custReciever.setAge(age);
			custReciever.setInitialBalance(recieverAmount);
			custReciever.setContactNo(newcontactNo);
			custReciever.setName(name);
			
			custMap.put(newcontactNo, custReciever);	
			System.out.println("FUND TRANSFERED! CURRENT BALANCE:"+senderAmount);
		}
		else{
			System.out.println("CANNOT TRANSFER! MINIMUM BALANCE OF 500 SHOULD BE MAINTAINED IN SENDER'S ACCOUNT");
		}
		
	}

	@Override
	public boolean validateAccount(String contactNo) throws BankAccountException {
		Customer customer = custMap.get(contactNo);
		if(customer == null)
			return false;
		return true;
	}

}
