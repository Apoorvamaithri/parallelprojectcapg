package com.cg.plp.dao;

import com.cg.plp.dto.Customer;
import com.cg.plp.exception.BankAccountException;

public interface BankingDAO {

	public void createAccount(Customer customer);
	
	public void deposit(String phoneNo, double amount);
	
	public void withdraw(String phoneNo, double amount);
	
	public double checkBalance(String phoneNo);
	
	public void fundTransfer(String sender, String reciever, double amount);
	
	public boolean validateAccount(String phoneNo) throws BankAccountException;
	
}
