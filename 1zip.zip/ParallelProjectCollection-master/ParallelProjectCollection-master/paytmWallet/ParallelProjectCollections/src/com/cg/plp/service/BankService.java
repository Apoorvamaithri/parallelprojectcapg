package com.cg.plp.service;

import com.cg.plp.dto.Customer;
import com.cg.plp.exception.BankAccountException;

public interface BankService {

	public void createAccount(Customer customer);
	
	public void deposit(String contactNo, double amount);
	
	public void withdraw(String contactNo, double amount);
	
	public double checkBalance(String contactNo);
	
	public void fundTransfer(String sender, String reciever, double amount);
	
	
	public boolean validateAccount(String contactNo) throws BankAccountException;
	
	public boolean validateName(String name) throws BankAccountException;
	
	public boolean validateAge(float age) throws BankAccountException;
	
	public boolean validateContactNo(String contactNo) throws BankAccountException;
	
	public boolean validateAmount(double amount) throws BankAccountException;
			
}
