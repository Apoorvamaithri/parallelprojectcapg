package com.cg.bank.dao;

import java.util.Date;
import java.util.List;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import com.cg.bank.dto.Customer;
import com.cg.bank.dto.Transactions;



public class BankDaoImpl implements BankDao{
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	EntityManager manager;
	
	public BankDaoImpl(){
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("JPA-PU");
		manager =emf.createEntityManager();
	}
	
	//------------------------ 1. Wallet Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	createAccount(Customer customer)
		 - Input Parameters	:	Customer customer
		 - Return Type		:	void
		 - Author			:	CAPGEMINI
		 - Creation Date	:	10/30/2018
		 - Description		:	Adding Customer Account
		 ********************************************************************************************************/
	
	@Override
	public void createAccount(Customer customer){
		manager.getTransaction().begin();
		manager.persist(customer);
		Transactions t5= new Transactions();
		t5.setMobileNo(customer.getMobileNo());
		t5.setAmount(0);
		t5.setCd("credit");
		t5.setBalance(customer.getInitialBalance());
		Date date = new Date();
		t5.setDate(String.valueOf(dateFormat.format(date)));
		manager.persist(t5);
		manager.getTransaction().commit();
		System.out.println("Customer added\nName: "+customer.getName()+"\nMobile number: "+customer.getMobileNo()+"\nAge: "+customer.getAge()+"\nBalance: "+customer.getInitialBalance());
	}
	
	//------------------------ 1. Wallet Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	deposit(String mobileNo, double amount)
			 - Input Parameters	:	MonileNo and Amount
			 - Return Type		:	void
			 - Author			:	CAPGEMINI
			 - Creation Date	:	10/30/2018
			 - Description		:	Depositing Amount
			 ********************************************************************************************************/
	
	@Override
	public void deposit(String mobileNo, double amount) {
		manager.getTransaction().begin();
		Customer cust = manager.find(Customer.class, mobileNo);
		double amt =cust.getInitialBalance();
		amt=amt+amount;
		cust.setInitialBalance(amt);
		manager.getTransaction().commit();
		passbookD(cust,amount);
		System.out.println("Amount deposited! New balance: "+amt);
	}
	
	//------------------------ 1. Wallet Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	withdraw(String mobileNo, double amount)
		 - Input Parameters	:	MonileNo and Amount
		 - Return Type		:	void
		 - Author			:	CAPGEMINI
		 - Creation Date	:	10/30/2018
		 - Description		:	Withdrawing Amount
		 ********************************************************************************************************/
	
	@Override
	public void withdraw(String mobileNo, double amount) {
		manager.getTransaction().begin();
		Customer cust = manager.find(Customer.class, mobileNo);
		double amt =cust.getInitialBalance();
		if(amt-amount>=100){
			amt=amt-amount;
			cust.setInitialBalance(amt);
			manager.getTransaction().commit();
			passbookW(cust, amount);
			System.out.println("Amount withdrawn! New balance: "+amt);
		}
		else{
			System.out.println("Cannot withdraw! Minimum balance of Rs.100 should be maintained");
		}
	}
	
	//------------------------ 1. Wallet Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	checkBalance(String mobileNo)
		 - Input Parameters	:	MonileNo
		 - Return Type		:	double
		 - Author			:	CAPGEMINI
		 - Creation Date	:	10/30/2018
		 - Description		:	Checking Account Balance
		 ********************************************************************************************************/
	
	@Override
	public double checkBalance(String mobileNo) {
		Customer cust = manager.find(Customer.class, mobileNo);
		double amt =cust.getInitialBalance();
		System.out.println(amt);
		return amt;
	}
	
	//------------------------ 1. Wallet Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	fundTransfer(String sender, String reciever, double amount)
		 - Input Parameters	:	Sender's Mobile No.,Receiver's Mobile No. and Amount
		 - Return Type		:	void
		 - Author			:	CAPGEMINI
		 - Creation Date	:	10/30/2018
		 - Description		:	Transfer of Amount
		 ********************************************************************************************************/
	
	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		manager.getTransaction().begin();
		Customer cust1 = manager.find(Customer.class, sender);
		double amt1 =cust1.getInitialBalance();
		Customer cust2 = manager.find(Customer.class, reciever);
		double amt2 =cust2.getInitialBalance();
		if(amt1-amount>=100){
			amt1=amt1-amount;
			amt2=amt2+amount;
			cust1.setInitialBalance(amt1);
			cust2.setInitialBalance(amt2);
			manager.getTransaction().commit();
			System.out.println("Amount transferred!\nNew balance in "+sender+" account is "+amt1);
			passbookF(cust1, cust2, amount);
		}
		else{
			System.out.println("Cannot tranfer! Sender has to maintain minimum balance of Rs.100");
		}
	}
	
	//------------------------ 1. Wallet Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	validateAccount(String mobileNo)
		 - Input Parameters	:	 Mobile No.
		 - Return Type		:	Boolean
		 - Author			:	CAPGEMINI
		 - Creation Date	:	10/30/2018
		 - Description		:	Account Validation
		 ********************************************************************************************************/
			
	public boolean validateAccount(String mobileNo){
		Customer cust3=manager.find(Customer.class, mobileNo);
		if(cust3==null)
			return false;
		return true;
	}
	
	//------------------------ 1. Wallet Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	passbookD(Customer customer)
			 - Input Parameters	:	Customer
			 - Return Type		:	void
			 - Author			:	CAPGEMINI
			 - Creation Date	:	10/30/2018
			 - Description		:	Transaction entry in table for deposit
			 * @param amt 
			 ********************************************************************************************************/
	
	@Override
	public void passbookD(Customer customer, double amt1) {
		Transactions t1= new Transactions();
		t1.setMobileNo(customer.getMobileNo());
		t1.setBalance(customer.getInitialBalance());
		t1.setAmount(amt1);
		Date date = new Date();
		t1.setDate(String.valueOf(dateFormat.format(date)));
		t1.setCd("credit");
		manager.getTransaction().begin();
		manager.persist(t1);
		manager.getTransaction().commit();		
	}
	
	//------------------------ 1. Wallet Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	passbookW(Customer customer)
	 - Input Parameters	:	Customer
	 - Return Type		:	void
	 - Author			:	CAPGEMINI
	 - Creation Date	:	10/30/2018
	 - Description		:	Transaction entry in table for withdraw
	 ********************************************************************************************************/
	
	@Override
	public void passbookW(Customer customer, double amt) {
		Transactions t2= new Transactions();
		t2.setMobileNo(customer.getMobileNo());
		t2.setBalance(customer.getInitialBalance());
		t2.setAmount(amt);
		Date date = new Date();
		t2.setDate(String.valueOf(dateFormat.format(date)));
		t2.setCd("debit");
		manager.getTransaction().begin();
		manager.persist(t2);
		manager.getTransaction().commit();		
	}
	
	//------------------------ 1. Wallet Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	passbookD(Customer customer)
	 - Input Parameters	:	Customer
	 - Return Type		:	void
	 - Author			:	CAPGEMINI
	 - Creation Date	:	10/30/2018
	 - Description		:	Transaction entry in table for fund transfer
	 ********************************************************************************************************/
	
	@Override
	public void passbookF(Customer customer1, Customer customer2, double amt) {
		manager.getTransaction().begin();
		Transactions t3= new Transactions();
		Transactions t4= new Transactions();
		t3.setMobileNo(customer1.getMobileNo());
		t3.setBalance(customer1.getInitialBalance());
		t3.setAmount(amt);
		Date date = new Date();
		t3.setDate(String.valueOf(dateFormat.format(date)));
		t3.setCd("debit");
		manager.persist(t3);
		t4.setMobileNo(customer2.getMobileNo());
		t4.setBalance(customer2.getInitialBalance());
		t4.setAmount(amt);
		t4.setDate(String.valueOf(dateFormat.format(date)));
		t4.setCd("credit");
		manager.persist(t4);		
		manager.getTransaction().commit();		
	}
	
	//------------------------ 1. Wallet Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	passbookD(Customer customer)
		 - Input Parameters	:	Customer
		 - Return Type		:	void
		 - Author			:	CAPGEMINI
		 - Creation Date	:	10/30/2018
		 - Description		:	Retrieving all the transactions
		 ********************************************************************************************************/
	
	@Override
	public List<Transactions> getTransList(String mobileNo) {
		String qr = "select trans from Transactions trans where mobileNo ="+mobileNo;
		TypedQuery<Transactions> query = manager.createQuery(qr, Transactions.class);
		List<Transactions> list = query.getResultList();
		return list;
	}

}
