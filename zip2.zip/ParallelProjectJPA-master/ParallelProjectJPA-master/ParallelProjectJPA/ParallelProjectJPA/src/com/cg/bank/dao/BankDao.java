package com.cg.bank.dao;

import java.util.List;

import com.cg.bank.dto.Customer;
import com.cg.bank.dto.Transactions;

public interface BankDao {

	public void createAccount(Customer customer);
	
	public void deposit(String mobileNo, double amount);
	
	public void withdraw(String mobileNo, double amount);
	
	public double checkBalance(String mobileNo);
	
	public void fundTransfer(String sender, String reciever, double amount);

	public boolean validateAccount(String mobileNo);	
	
	public void passbookD(Customer customer, double amount);

	void passbookW(Customer customer, double amount);

	void passbookF(Customer customer1, Customer customer2, double amount);

	public List<Transactions> getTransList(String mobileNo);
}
