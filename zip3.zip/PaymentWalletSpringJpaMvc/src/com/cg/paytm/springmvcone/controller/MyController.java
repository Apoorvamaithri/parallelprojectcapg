package com.cg.paytm.springmvcone.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.paytm.springmvcone.dto.Customer;
import com.cg.paytm.springmvcone.dto.Transactions;
import com.cg.paytm.springmvcone.service.IBankingService;



@Controller
public class MyController {

	@Autowired
	IBankingService bankingservice;
	
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll() {
		return "home";
	}
	
	
	/*************CREATING ACCOUNT********************/
	
	
	@RequestMapping(value="CreateAccount",method=RequestMethod.GET)
	public String create(@ModelAttribute("my") Customer cust) {
		System.out.println("returning createaccount");
		
		return "createaccount";
	}

	@RequestMapping(value="insert",method=RequestMethod.POST)
	public String insertingcust(@ModelAttribute("my") Customer cust) {
		bankingservice.createAccount(cust);
		System.out.println("returning Success");
		return "success";
	}
	
	
	/*************DEPOSITING INTO ACCOUNT********************/
	
	
	@RequestMapping(value="Deposit",method=RequestMethod.GET)
	public String DepositEmployee() {
		return "deposit";
	}
	@RequestMapping(value="dodeposit",method=RequestMethod.GET)
	public String depositamount(@RequestParam("contactNo") String id, @RequestParam("initialBalance") double initbal) {
		bankingservice.deposit(id,initbal);
		return "success";
	}
	
	
	/*************WITHDRAWING AMOUNT FROM ACCOUNT********************/
	
	
	@RequestMapping(value="withdraw", method=RequestMethod.GET)
	public String withdrawing() {
		System.out.println("in withdraw()");
		return "withdraw";
	}
	@RequestMapping(value="dowithdraw",method=RequestMethod.GET)
	public String dowithdrawamount(@RequestParam("contactNo") String id, @RequestParam("initialBalance") double initbal) {
		bankingservice.withdraw(id,initbal);
		return "success";
	}
	
	
	/*************CHECKING BALANCE IN ACCOUNT********************/
	
	
	@RequestMapping(value="checkbalance", method=RequestMethod.GET)
	public String checkingbal() {
		System.out.println("in checkbalance()");
		return "checkbalance";
	}
	@RequestMapping(value = "docheckbalance", method = RequestMethod.GET)
	public String docheckbalance(@RequestParam("contactNo")String contNo ){
		bankingservice.checkBalance(contNo );
		return "success";
	}
	
	
	/************* FUND TRANSFERRING ********************/
	
	
	@RequestMapping(value="fundtransfer", method=RequestMethod.GET)
	public String fundtransfering() {
		System.out.println("in fundtransfer() controller");
		return "fundtransfer";
	}
	@RequestMapping(value = "dofundtransfer", method = RequestMethod.GET)
	public String dofundtransfer(@RequestParam("senderNo") String senderNo, @RequestParam("recieverNo") String recieverNo, @RequestParam("initialBalance") double amt){
     
		bankingservice.fundTransfer(senderNo,recieverNo,amt );
		return "success";
	}
	
	
	
	/***************************Print Transaction*****************/
	
	
	@RequestMapping(value = "printtransactions",method = RequestMethod.GET)
	public String transactionadata(){
		return "printtransaction";
	}
	
	@RequestMapping(value="doprinttransactions", method=RequestMethod.GET)
	public ModelAndView Ptrans(@RequestParam("mobno") String mobileNo)
	{
		if(bankingservice.accountExist(mobileNo))
		{
			return new ModelAndView("accountnotexist");
		}
			
		else
		{
			List<Transactions> trans = bankingservice.getTransList(mobileNo);
			
			return new ModelAndView("printtranssuccess","trans",trans);
		}
}
}
