package com.cg.paytm.springmvcone.service;

import java.util.List;

import com.cg.paytm.springmvcone.dto.Customer;
import com.cg.paytm.springmvcone.dto.Transactions;

public interface IBankingService {

	public void createAccount(Customer customer);
	
	public void deposit(String id, double amount);
	
	public void withdraw(String contactNo, double amount);
	
	public double checkBalance(String contactNo);
	
	public void fundTransfer(String senderNo, String recieverNo, double amount);
	
	public boolean accountExist(String custMobileNo);

	List<Transactions> getTransList(String mobileNo);

}
