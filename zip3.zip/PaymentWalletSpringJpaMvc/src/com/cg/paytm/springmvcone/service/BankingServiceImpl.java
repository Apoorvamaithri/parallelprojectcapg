 package com.cg.paytm.springmvcone.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.paytm.springmvcone.dao.BankingDAO;
import com.cg.paytm.springmvcone.dto.Customer;
import com.cg.paytm.springmvcone.dto.Transactions;



@Service("bankingservice")
@Transactional
public class BankingServiceImpl implements IBankingService {
  
	@Autowired
	BankingDAO bankingdao;

@Override
public void createAccount(Customer customer) {
	System.out.println("createAccountSerImpl()");
	 bankingdao.createAccount(customer);
	
}

@Override
public void deposit(String cn, double amount) {
	System.out.println("deposit service()");
	
	 bankingdao.deposit(cn, amount);
}

@Override
public void withdraw(String contactNo, double amount) {
	System.out.println("withdraw service()");
	bankingdao.withdraw(contactNo, amount);
}

@Override
public double checkBalance(String contactNo) {
	System.out.println("checkbalance service()");
	
	return bankingdao.checkBalance(contactNo);
}

@Override
public void fundTransfer(String sender, String reciever, double amount) {
	System.out.println("fundTransfer service()");
	bankingdao.fundTransfer(sender, reciever,amount);
	
}

@Override
public boolean accountExist(String custMobileNo) {
	return bankingdao.accountExist(custMobileNo);
	
}

@Override
public List<Transactions> getTransList(String mobileNo) {
	
	return bankingdao.getTransList(mobileNo);
}





}
