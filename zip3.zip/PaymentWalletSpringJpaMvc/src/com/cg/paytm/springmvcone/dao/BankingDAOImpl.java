package com.cg.paytm.springmvcone.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.paytm.springmvcone.dto.Customer;
import com.cg.paytm.springmvcone.dto.Transactions;

@Repository("bankingdao")
public class BankingDAOImpl implements BankingDAO{

	@PersistenceContext
	EntityManager manager;
	
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	@Override
	public void createAccount(Customer customer) {
		System.out.println("in createAccount() of daoimpl");
		// TODO Auto-generated method stub
		Transactions t1 = new Transactions();
		manager.persist(customer);
		t1.setCustMobileNo(customer.getContactNo());
		t1.setTransamount(0);
		t1.setCre_deb("credit");
		t1.setBalance(customer.getInitialBalance());
		Date date = new Date();
		t1.setDate(String.valueOf(dateFormat.format(date)));
		
		manager.persist(t1);
	    manager.flush();
		
		//System.out.println("Customer added\nName: "+customer.getName()+"\nMobile number: "+customer.getContactNo()+"\nAge: "+customer.getAge()+"\nBalance: "+customer.getInitialBalance());
	}

	@Override
	public void deposit(String contactNo, double amount) {
		System.out.println("depositDaoImpl()");
		Transactions t4 = new Transactions();
		Customer customer = manager.find(Customer.class, contactNo);
		double iniBal=customer.getInitialBalance();
		iniBal+=amount;
		customer.setInitialBalance(iniBal);
		t4.setCustMobileNo(contactNo);
		t4.setBalance(iniBal);
		t4.setTransamount(amount);
		t4.setCre_deb("Credit");
		Date date = new Date();
		t4.setDate(String.valueOf(dateFormat.format(date)));
		manager.persist(customer);
		manager.persist(t4);
		manager.flush();
	}

	@Override
	public void withdraw(String contactNo, double withdrawamount) {
		Transactions t5 = new Transactions();
		Customer customer = manager.find(Customer.class, contactNo);
		double iniBal=customer.getInitialBalance();
		iniBal-=withdrawamount;
		System.out.println(iniBal);
		customer.setInitialBalance(iniBal);
		t5.setCustMobileNo(contactNo);
		t5.setCre_deb("Debit");
		t5.setBalance(iniBal);
		t5.setTransamount(withdrawamount);
		Date date = new Date();
		t5.setDate(String.valueOf(dateFormat.format(date)));
		manager.persist(customer);
		manager.persist(t5);
		manager.flush();
		
		
	}

	@Override
	public double checkBalance(String contactNo) {
		Customer cust = manager.find(Customer.class, contactNo);
		double amt =cust.getInitialBalance();
		System.out.println(amt);
		return amt;
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		Transactions t3 = new Transactions();
		Transactions t4 = new Transactions();
		Customer cust1 = manager.find(Customer.class, sender);
		double amt1 =cust1.getInitialBalance();
		Customer cust2 = manager.find(Customer.class, reciever);
		double amt2 =cust2.getInitialBalance();
		amt1=amt1-amount;
		amt2=amt2+amount;
		cust1.setInitialBalance(amt1);
		cust2.setInitialBalance(amt2);
		t3.setCustMobileNo(sender);
		t3.setBalance(amt1);
		t3.setCre_deb("Debit");
		t3.setTransamount(amount);
		Date date = new Date();
		t3.setDate(String.valueOf(dateFormat.format(date)));
		manager.persist(t3);
		t4.setCustMobileNo(reciever);
		t4.setCre_deb("Credit");
		t4.setBalance(amt2);
		t4.setTransamount(amount);
		Date date2 = new Date();
		t4.setDate(String.valueOf(dateFormat.format(date2)));
		manager.persist(cust1);
		manager.persist(t4);
		manager.flush();	
	}

	@Override
	public boolean accountExist(String custMobileNo) {
		
		Customer cust = manager.find(Customer.class,custMobileNo);
		if(cust==null)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public List<Transactions> getTransList(String mobileNo) {
		
		String qr = "select trans from Transactions trans where mobileNo ="+mobileNo;
		TypedQuery<Transactions> query = manager.createQuery(qr, Transactions.class);
		List<Transactions> list = query.getResultList();
		return list;
	}
	

}
