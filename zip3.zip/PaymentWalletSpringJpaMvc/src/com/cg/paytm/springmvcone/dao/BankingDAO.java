package com.cg.paytm.springmvcone.dao;


import java.util.List;

import com.cg.paytm.springmvcone.dto.Customer;
//import com.cg.paytm.springmvcone.exception.BankAccountException;
import com.cg.paytm.springmvcone.dto.Transactions;



public interface BankingDAO {
	
   public void createAccount(Customer customer);
	
	public void withdraw(String phoneNo, double amount);
	
	public double checkBalance(String phoneNo);
	
	public void fundTransfer(String sender, String reciever, double amount);
	
	//public boolean validateAccount(double phoneNo); //throws BankAccountException;

	public void deposit(String cn, double amount);

	public boolean accountExist(String custMobileNo);

	public List<Transactions> getTransList(String mobileNo);
}
