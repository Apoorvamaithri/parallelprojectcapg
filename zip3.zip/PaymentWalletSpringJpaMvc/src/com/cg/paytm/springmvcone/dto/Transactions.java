package com.cg.paytm.springmvcone.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
@Table(name="transactionsSPRING")
public class Transactions
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID",length=20)
	private int index;

	@Column(name="mobileno",length=10)
	@NotEmpty
	private String custMobileNo;

	@Column(name="creditORdebit",length=15)
	@NotEmpty
	private String cre_deb;

	@Column(name="Balance",length=5)
	@NotEmpty
	private double balance;

	@Column(name="amount",length=5)
	@NotEmpty
	private double transamount;

	@Column(name="transtime",length=20)
	@NotEmpty
	private String date;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getCustMobileNo() {
		return custMobileNo;
	}

	public void setCustMobileNo(String custMobileNo) {
		this.custMobileNo = custMobileNo;
	}

	public String getCre_deb() {
		return cre_deb;
	}

	public void setCre_deb(String cre_deb) {
		this.cre_deb = cre_deb;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getTransamount() {
		return transamount;
	}

	public void setTransamount(double transamount) {
		this.transamount = transamount;
	}

	public Transactions() {
		super();
		// TODO Auto-generated constructor stub
	}


}

