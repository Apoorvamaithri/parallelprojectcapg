package com.cg.paytm.springmvcone.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="customerspring")
public class Customer {

		@Column(name = "cust_name")
		@NotEmpty
		@NotNull
		private String name;
		
		@Id
		@Column(name = "cust_contactno")
		@NotEmpty
		@NotNull
		private String contactNo;
		
		@Column(name = "cust_age")
		@NotEmpty
		@NotNull
		private float age;
		
		@Column(name = "cust_initialBal")
		@NotEmpty
		@NotNull
		private double initialBalance;
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		public String getContactNo() {
			return contactNo;
		}
		public void setContactNo(String contactNo) {
			 this.contactNo = contactNo;
		}
		
		public float getAge() {
			return age;
		}
		public void setAge(float age) {
			this.age = age;
		}
		
		public double getInitialBalance() {
			return initialBalance;
		}
		public void setInitialBalance(double initialBalance) {
			this.initialBalance = initialBalance;
		}
		public Customer(String name, String contactNo, float age, double initialBalance) {
			this.name = name;
			this.contactNo = contactNo;
			this.age = age;
			this.initialBalance = initialBalance;
		}
		public Customer() {
			super();
			System.out.println("in superclass of Customer");
			
		}
}
